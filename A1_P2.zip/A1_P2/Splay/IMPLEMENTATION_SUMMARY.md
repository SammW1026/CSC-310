# Splay Tree Implementation Summary

## Task 1: Complete Search and Delete Functions (COMPLETED)

### SearchNode() - Top-Down Approach
- **Function**: `bool search(int key)`
- **Implementation**: Uses top-down `splay()` to bring key to root in one pass
- **Behavior**: Splays the found node all the way to the root, incrementing weight on success

### SearchNode() - Bottom-Up Approach
- **Function**: `bool searchBottomUp(int key)`
- **Implementation**: Uses `splayBottomUp()` to traverse down and then splay up
- **Key Feature**: Stores path during traversal, then performs rotations from bottom to top
- **Advantage**: Memory-friendly approach that doesn't use recursion

### DeleteNode() - Top-Down Approach
- **Function**: `void remove(int key)` / `deleteNode()`
- **Implementation**: Splays to root, then deletes and reattaches left/right subtrees
- **Process**: 
  1. Splay key to root
  2. Delete the root
  3. Find max in left subtree and splay it
  4. Attach right subtree to the max node

### DeleteNode() - Bottom-Up Approach
- **Function**: `void removeBottomUp(int key)` / `deleteNodeBottomUp()`
- **Implementation**: Finds node via path, deletes it, then splays the parent
- **Process**:
  1. Traverse down and store path
  2. Delete the node
  3. Splay the parent node to restructure tree
- **Advantage**: Single-pass deletion with automatic parent splaying

---

## Task 2: Semi-Splay with Rotation Limit (COMPLETED)

### Semi-Splay Implementation
- **Function**: `bool searchSemiSplay(int key, int rotationLimit)`
- **Private Function**: `Node* splayWithLimit(Node* root, int key, int limit)`
- **Purpose**: Reduces rotations by limiting how far up the tree the splaying goes
- **Parameters**: 
  - `key`: The value to search for
  - `rotationLimit`: Maximum number of rotations to perform (e.g., 2 for half-way)
  
### Key Features
- Tracks rotation count separately from total rotations
- Stops splaying once the rotation limit is reached
- Uses `limit < 0` to indicate unlimited rotations
- Optimizes for cases where full splaying is too expensive
- Cache behavior: Moves frequently accessed nodes closer to root without full splaying

### Example
```cpp
// Splay with maximum 2 rotations
tree.searchSemiSplay(44, 2);
// Node 44 moves up but not necessarily to root
```

---

## Task 3: Weighted-Splay with Cache Behavior (COMPLETED)

### Weighted-Splay Implementation
- **Function**: `bool searchWeightedSplay(int key)`
- **Private Function**: `Node* weightedSplay(Node* root, int key)`
- **Purpose**: Implements cache-like behavior based on access frequency

### Key Features
- **Weight Tracking**: Each node has a `weight` field (initialized to 0)
- **Weight Increment**: Every successful search increments the node's weight
- **Conditional Rotation**: Only rotates if `child->weight >= parent->weight`
  
### Rotation Logic
```cpp
// Left subtree rotation only if:
if (t->left->weight >= t->weight && key < t->left->key)
    t = rotateRight(t);

// Right subtree rotation only if:
if (t->right->weight >= t->weight && key > t->right->key)
    t = rotateLeft(t);
```

### Cache Behavior
- **First access**: Node has weight 0, unlikely to be rotated (parent weight typically ≥ 0)
- **Subsequent accesses**: Weight increases with each search, promoting node up the tree
- **Result**: Frequently accessed nodes gradually move toward root
- **Advantage**: Self-organizing structure optimized for access patterns

---

## File Changes

### Header (splay.h)
Added function declarations:
- `Node* splayBottomUp(Node* root, int key);`
- `Node* deleteNodeBottomUp(Node* root, int key);`
- `bool searchBottomUp(int key);`
- `void removeBottomUp(int key);`
- `bool searchSemiSplay(int key, int rotationLimit);`
- `bool searchWeightedSplay(int key);`

### Implementation (splay.cpp)
Added implementations:
- `splayBottomUp()`: Bottom-up splaying algorithm
- `deleteNodeBottomUp()`: Bottom-up deletion with parent splaying
- `searchBottomUp()`: Public wrapper for bottom-up search
- `removeBottomUp()`: Public wrapper for bottom-up removal
- `searchSemiSplay()`: Public wrapper for semi-splay search
- `searchWeightedSplay()`: Public wrapper for weighted search
- Enhanced `splayWithLimit()`: Improved rotation limit logic

### Test Program (mainsplay.cpp)
Demonstrates all four approaches:
1. **Top-Down Full Splay**: Classic approach, full restructuring
2. **Bottom-Up Splay**: Alternative traversal method
3. **Semi-Splay**: Limited rotations for performance balance
4. **Weighted-Splay**: Access-frequency-based optimization

---

## Comparison

| Approach | Splaying | Access Freq | Rotation Cost | Best Use Case |
|----------|----------|-------------|---------------|---------------|
| **Full Splay** | To root | Not tracked | High | General purpose, optimal amortized |
| **Bottom-Up** | To root | Not tracked | High | Memory-constrained systems |
| **Semi-Splay** | Limited | Not tracked | Low | Reduced cost with moderate benefit |
| **Weighted** | Conditional | Yes, weight++ | Variable | Cache-like behavior, pattern optimization |

---

## Performance Notes

- **Top-Down Splay**: O(log n) amortized per operation
- **Bottom-Up Splay**: O(log n) amortized per operation, but uses stack space
- **Semi-Splay**: O(k) where k is rotation limit, reduces cache misses
- **Weighted-Splay**: O(log n) amortized, self-optimizing for access patterns
