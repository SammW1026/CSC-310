#include "mst.h"
#include "binaryHeap.h"      // Custom binary heap
#include "binomialHeap.h"    // Custom binomial heap
#include "customErrorClass.h"

// =====================================================================
// Task 1: QuickUnion
// =====================================================================
QuickUnion::QuickUnion(int n)
{
    if (n <= 0) {
        throw MyException("QuickUnion: number of elements must be positive.");
    }
    parent.resize(n);
    for (int i = 0; i < n; ++i) {
        parent[i] = i;
    }
}

int QuickUnion::find(int x)
{
    if (x < 0 || x >= (int)parent.size()) {
        throw MyException("QuickUnion::find -> index out of range.");
    }
    while (parent[x] != x) {
        x = parent[x];
    }
    return x;
}

void QuickUnion::Union(int x, int y)
{
    int rootX = find(x);
    int rootY = find(y);
    if (rootX == rootY) return;
    parent[rootX] = rootY;
}

// =====================================================================
// Task 2: UnionFind (path compression + union by size)
// =====================================================================
UnionFind::UnionFind(int n)
{
    if (n <= 0) {
        throw MyException("UnionFind: number of elements must be positive.");
    }
    parent.resize(n);
    rank.resize(n, 1);
    for (int i = 0; i < n; ++i) {
        parent[i] = i;
    }
}

int UnionFind::find(int x)
{
    if (x < 0 || x >= (int)parent.size()) {
        throw MyException("UnionFind::find -> index out of range.");
    }
    if (parent[x] != x) {
        parent[x] = find(parent[x]);
    }
    return parent[x];
}

void UnionFind::Union(int x, int y)
{
    int rootX = find(x);
    int rootY = find(y);
    if (rootX == rootY) return;

    if (rank[rootX] < rank[rootY]) {
        parent[rootX] = rootY;
        rank[rootY]  += rank[rootX];
    } else {
        parent[rootY] = rootX;
        rank[rootX]  += rank[rootY];
    }
}

// =====================================================================
// MST
// =====================================================================
MST::MST(int vertices)
{
    if (vertices <= 0) {
        throw MyException("MST: vertex count must be positive.");
    }
    n = vertices;
}

void MST::addEdge(int u, int v, int weight)
{
    if (u < 0 || v < 0 || u >= n || v >= n) {
        throw MyException("MST::addEdge -> vertex index out of range.");
    }
    edges.push_back({u, v, weight});
}

// =====================================================================
// Task 3: kruskalV1  (Binary Heap + QuickUnion)
// =====================================================================
int MST::kruskalV1()
{
    if (edges.empty()) {
        throw MyException("kruskalV1 -> graph has no edges.");
    }

    HEAP heap((int)edges.size());
    for (const Edge& e : edges) {
        heap.insertH(e);
    }

    QuickUnion uf(n);
    int totalCost  = 0;
    int edgesUsed  = 0;

    try {
        while (edgesUsed < n - 1) {
            Edge e = heap.peek();
            heap.deleteMin();

            if (e.src == -1 && e.dest == -1 && e.weight == -1) {
                throw MyException("kruskalV1 -> graph is disconnected (heap exhausted).");
            }

            int rootU = uf.find(e.src);
            int rootV = uf.find(e.dest);
            if (rootU != rootV) {
                uf.Union(rootU, rootV);
                totalCost += e.weight;
                ++edgesUsed;
            }
        }
    } catch (MyException& ex) {
        cerr << "kruskalV1 error: " << ex.what() << endl;
        throw;
    }

    return totalCost;
}

// =====================================================================
// Task 4: kruskalV2  (Binomial Heap + Union-Find)
// =====================================================================
int MST::kruskalV2()
{
    if (edges.empty()) {
        throw MyException("kruskalV2 -> graph has no edges.");
    }

    BinomialHeap heap;
    for (const Edge& e : edges) {
        heap.insert(e);
    }

    UnionFind uf(n);
    int totalCost = 0;
    int edgesUsed = 0;
    int totalEdges = (int)edges.size();
    int processed  = 0;

    try {
        while (edgesUsed < n - 1) {
            if (processed >= totalEdges) {
                throw MyException("kruskalV2 -> graph is disconnected (heap exhausted).");
            }
            Edge e = heap.findMin();
            heap.deleteMin();
            ++processed;

            int rootU = uf.find(e.src);
            int rootV = uf.find(e.dest);
            if (rootU != rootV) {
                uf.Union(rootU, rootV);
                totalCost += e.weight;
                ++edgesUsed;
            }
        }
    } catch (MyException& ex) {
        cerr << "kruskalV2 error: " << ex.what() << endl;
        throw;
    }

    return totalCost;
}
