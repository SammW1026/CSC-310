#include "binomialHeap.h"
#include "customErrorClass.h"

binomialNode::binomialNode(Edge e)
    : edge(e), degree(0), parent(nullptr), child(nullptr), sibling(nullptr) {}

BinomialHeap::BinomialHeap() : head(nullptr) {}

binomialNode* BinomialHeap::reverseList(binomialNode* node)
{
    binomialNode* prev = nullptr;
    binomialNode* curr = node;
    while (curr) {
        binomialNode* next = curr->sibling;
        curr->sibling = prev;
        curr->parent  = nullptr;
        prev = curr;
        curr = next;
    }
    return prev;
}

binomialNode* BinomialHeap::mergeTrees(binomialNode* tree1, binomialNode* tree2)
{
    tree2->parent  = tree1;
    tree2->sibling = tree1->child;
    tree1->child   = tree2;
    tree1->degree++;
    return tree1;
}

binomialNode* BinomialHeap::unionHeaps(binomialNode* heap1, binomialNode* heap2)
{
    if (!heap1) return heap2;
    if (!heap2) return heap1;

    binomialNode* h;
    binomialNode* tail;

    if (heap1->degree <= heap2->degree) {
        h = heap1;
        heap1 = heap1->sibling;
    } else {
        h = heap2;
        heap2 = heap2->sibling;
    }
    tail = h;

    while (heap1 && heap2) {
        if (heap1->degree <= heap2->degree) {
            tail->sibling = heap1;
            heap1 = heap1->sibling;
        } else {
            tail->sibling = heap2;
            heap2 = heap2->sibling;
        }
        tail = tail->sibling;
    }
    tail->sibling = (heap1) ? heap1 : heap2;
    return h;
}

void BinomialHeap::insert(Edge edge)
{
    BinomialHeap temp;
    temp.head = new binomialNode(edge);
    merge(temp);
    temp.head = nullptr;
}

void BinomialHeap::merge(BinomialHeap& other)
{
    head = unionHeaps(head, other.head);
    other.head = nullptr;
    if (!head) return;

    binomialNode* prev = nullptr;
    binomialNode* curr = head;
    binomialNode* next = curr->sibling;

    while (next) {
        if (curr->degree != next->degree ||
            (next->sibling && next->sibling->degree == curr->degree)) {
            prev = curr;
            curr = next;
        }
        else if (curr->edge.weight <= next->edge.weight) {
            curr->sibling = next->sibling;
            mergeTrees(curr, next);
        }
        else {
            if (!prev) head = next;
            else       prev->sibling = next;
            mergeTrees(next, curr);
            curr = next;
        }
        next = curr->sibling;
    }
}

Edge BinomialHeap::findMin()
{
    if (!head) {
        throw MyException("BinomialHeap::findMin -> heap is empty.");
    }
    binomialNode* minNode = head;
    binomialNode* curr    = head->sibling;
    while (curr) {
        if (curr->edge.weight < minNode->edge.weight) {
            minNode = curr;
        }
        curr = curr->sibling;
    }
    return minNode->edge;
}

void BinomialHeap::deleteMin()
{
    if (!head) {
        throw MyException("BinomialHeap::deleteMin -> heap is empty.");
    }

    binomialNode* minNode     = head;
    binomialNode* prevMinNode = nullptr;
    binomialNode* prev        = nullptr;
    binomialNode* curr        = head;
    while (curr) {
        if (curr->edge.weight < minNode->edge.weight) {
            minNode     = curr;
            prevMinNode = prev;
        }
        prev = curr;
        curr = curr->sibling;
    }

    if (prevMinNode) prevMinNode->sibling = minNode->sibling;
    else             head = minNode->sibling;

    BinomialHeap temp;
    temp.head = reverseList(minNode->child);
    delete minNode;
    merge(temp);
}

binomialNode* BinomialHeap::findNode(binomialNode* node, Edge edge)
{
    if (!node) return nullptr;
    if (node->edge.src == edge.src &&
        node->edge.dest == edge.dest &&
        node->edge.weight == edge.weight) {
        return node;
    }
    binomialNode* res = findNode(node->child, edge);
    if (res) return res;
    return findNode(node->sibling, edge);
}

void BinomialHeap::decreaseKey(Edge oldEdge, Edge newEdge)
{
    if (newEdge.weight > oldEdge.weight) {
        throw MyException("decreaseKey -> new key is greater than current key.");
    }
    binomialNode* node = findNode(head, oldEdge);
    if (!node) {
        throw MyException("decreaseKey -> edge not found.");
    }
    node->edge = newEdge;
    binomialNode* curr = node;
    binomialNode* p    = curr->parent;
    while (p && curr->edge.weight < p->edge.weight) {
        Edge tmp   = curr->edge;
        curr->edge = p->edge;
        p->edge    = tmp;
        curr = p;
        p    = curr->parent;
    }
}

void BinomialHeap::deleteKey(Edge edge)
{
    Edge sentinel{edge.src, edge.dest, INT32_MIN};
    decreaseKey(edge, sentinel);
    deleteMin();
}

void BinomialHeap::printTree(binomialNode* node, int space)
{
    if (!node) return;
    space += 4;
    printTree(node->child, space);
    cout << setw(space) << node->edge.weight << "\n";
    printTree(node->sibling, space);
}

void BinomialHeap::printHeap()
{
    binomialNode* curr = head;
    while (curr) {
        cout << "B" << curr->degree << " tree:\n";
        printTree(curr, 0);
        curr = curr->sibling;
    }
}
