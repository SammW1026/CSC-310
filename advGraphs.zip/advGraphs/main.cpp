#include "mst.h"
#include "customErrorClass.h"

void testSmallInput() {
    cout << "=== Small Graph Test (6 nodes) ===" << endl;
    MST graph(6);

    graph.addEdge(0, 1, 4);
    graph.addEdge(0, 2, 4);
    graph.addEdge(1, 2, 2);
    graph.addEdge(1, 3, 5);
    graph.addEdge(2, 3, 5);
    graph.addEdge(2, 4, 11);
    graph.addEdge(3, 4, 2);
    graph.addEdge(4, 5, 1);
    graph.addEdge(3, 5, 7);

    cout << "Running Baseline MST (Binary Heap + Quick Union)..." << endl;
    auto start1 = chrono::high_resolution_clock::now();
    int cost1   = graph.kruskalV1();
    auto end1   = chrono::high_resolution_clock::now();
    chrono::duration<double> elapsed1 = end1 - start1;
    cout << "MST Cost: "   << cost1            << endl;
    cout << "Time taken: " << elapsed1.count() << " seconds" << endl << endl;

    cout << "Running Optimized MST (Binomial Heap + Union-Find)..." << endl;
    auto start2 = chrono::high_resolution_clock::now();
    int cost2   = graph.kruskalV2();
    auto end2   = chrono::high_resolution_clock::now();
    chrono::duration<double> elapsed2 = end2 - start2;
    cout << "MST Cost: "   << cost2            << endl;
    cout << "Time taken: " << elapsed2.count() << " seconds" << endl << endl;
}

void testRandomGraph(int numNodes, int numEdges) {
    cout << "=== Random Graph Test (" << numNodes
         << " nodes, " << numEdges << " edges) ===" << endl;
    MST graph(numNodes);
    srand(42);

    for (int i = 0; i < numNodes - 1; ++i) {
        int weight = 1 + rand() % 100;
        graph.addEdge(i, i + 1, weight);
    }

    int addedEdges = numNodes - 1;
    while (addedEdges < numEdges) {
        int u = rand() % numNodes;
        int v = rand() % numNodes;
        if (u != v) {
            int weight = 1 + rand() % 1000;
            graph.addEdge(u, v, weight);
            ++addedEdges;
        }
    }

    cout << "Running Baseline MST (Binary Heap + Quick Union)..." << endl;
    auto start1 = chrono::high_resolution_clock::now();
    int cost1   = graph.kruskalV1();
    auto end1   = chrono::high_resolution_clock::now();
    chrono::duration<double> elapsed1 = end1 - start1;
    cout << "MST Cost: "   << cost1            << endl;
    cout << "Time taken: " << elapsed1.count() << " seconds" << endl << endl;

    cout << "Running Optimized MST (Binomial Heap + Union-Find)..." << endl;
    auto start2 = chrono::high_resolution_clock::now();
    int cost2   = graph.kruskalV2();
    auto end2   = chrono::high_resolution_clock::now();
    chrono::duration<double> elapsed2 = end2 - start2;
    cout << "MST Cost: "   << cost2            << endl;
    cout << "Time taken: " << elapsed2.count() << " seconds" << endl << endl;
}

void testExceptionHandling() {
    cout << "=== Exception Handling Test ===" << endl;
    try {
        MST emptyGraph(5);
        emptyGraph.kruskalV1();
    } catch (MyException& e) {
        cout << "Caught expected exception (kruskalV1, no edges): "
             << e.what() << endl;
    }

    try {
        MST badGraph(3);
        badGraph.addEdge(0, 7, 4);
    } catch (MyException& e) {
        cout << "Caught expected exception (out-of-range vertex): "
             << e.what() << endl;
    }

    try {
        MST badSize(0);
    } catch (MyException& e) {
        cout << "Caught expected exception (zero vertices): "
             << e.what() << endl;
    }
    cout << endl;
}

int main() {
    try {
        testExceptionHandling();

        // Small input range (10 - 100 nodes)
        testSmallInput();
        testRandomGraph(50,  150);
        testRandomGraph(100, 400);

        // Large input range (> 10,000 nodes)
        testRandomGraph(20000,  100000);
        testRandomGraph(100000, 500000);
    } catch (MyException& e) {
        cerr << "Fatal MyException: " << e.what() << endl;
        return 1;
    } catch (std::exception& e) {
        cerr << "Fatal std::exception: " << e.what() << endl;
        return 1;
    }

    return 0;
}
